import openai
from django.conf import settings
from .utils import client

openai.api_key = settings.OPENAI_API_KEY

class AIroadmap():
    def generate_roadmap(subjects, goals, reasons, start_level, strengths, weaknesses):

                prompt_text = "You are an AI that will help people learn. You will generate a detailed roadmap consisting of at least 6 steps based on the topic the user wants to learn, with at least 2 resources for every step. The user wants to learn about " + subjects + ". The user goal is " + goals + " and their reason for learning the subject is " + reasons + ". The user's current level is " + start_level + ". Their strengths are " + strengths + " and their weaknesses are " + weaknesses + ". Please format the reponse in a nice html."

                response = client.completions.create(
                    model="gpt-3.5-turbo-instruct",
                    prompt=prompt_text,
                    max_tokens=500,
                )

                roadmap = response.choices[0].text.strip()

                return roadmap