from django.urls import path
from . import views

urlpatterns = [
    path("", views.home),
    path("home/", views.home),

    path("sign-up/", views.sign_up),
    path("account/", views.account),

    path("learning-steps/", views.steps),
    path("learning-steps/new/", views.newlesson, name="add-lesson"),
    path("learning-steps/<slug:slug>/", views.viewRoadmap),

    path("group/", views.group_list),
    path("group/<slug:slug>/", views.group, name="group")
]